//
//  MySwiftAssignmentTests.swift
//  MySwiftAssignmentTests
//
//  Created by Nisum Technologies on 18/07/2017.
//  Copyright © 2017 Nisum Technologies. All rights reserved.
//

import XCTest
@testable import MySwiftAssignment

class MySwiftAssignmentTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        
        
        let checkTest = HomeViewController()
        weak let selectedTextField : setTextField = setTextField(coder: NSCoder)

        selectedTextField.text = "2"
        if !(selectedTextField.text?.isEmpty)! {
            
            let txtValue = Float(selectedTextField.text!)
            
            print(txtValue! - checkTest.depositExpected)
            checkTest.lblVariance.text = String(txtValue! - checkTest.depositExpected)
        }

        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
